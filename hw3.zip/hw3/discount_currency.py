discount=0
def set_rate(rate_f):
    global discount
    discount=rate_f
def get_rate():
    return discount
def get_fixed_price(price_f):
    return price_f*100/(100-discount)
def main():
    set_rate(20)
    print(get_fixed_price(8000))
if __name__=="__main__":
    main()

