import discount_currency as dc
rate=int(input("할인율은? "))
dc.set_rate(rate)
a_price=int(input("A 상품의 할인된 가격은? "))
b_price=int(input("B 상품의 할인된 가격은? "))
print("A 상품의 정가는",int(dc.get_fixed_price(a_price)),"원")
print("B 상품의 정가는",int(dc.get_fixed_price(b_price))20,"원")